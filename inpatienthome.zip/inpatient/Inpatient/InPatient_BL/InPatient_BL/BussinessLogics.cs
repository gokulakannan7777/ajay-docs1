﻿using InPatient_DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace InPatient_BL
{
    public class BussinessLogics
    {
        DataLogics datalogicsobj;
        public int PatientRegistrationInfo(string pId, string fname, string lname, string cname, string mobile, string address, string email, string occupation, string orgworking, DateTime joiningdate, string gender, string Reason, string username, string Password)
        {
            datalogicsobj = new DataLogics();
            return datalogicsobj.PatientRegistration(pId, fname, lname, cname, mobile, address, email, occupation, orgworking, joiningdate, gender, Reason, username, Password);
        }
        public int allocateInfo(string patientId,string RoomType,string RoomNum,string BedNum,string equipment)
        {
            datalogicsobj = new DataLogics();
            return datalogicsobj.Allocate(patientId, RoomType, RoomNum, BedNum, equipment);
        }
        public int deleteDoctorInfo(string docId)
        {
            datalogicsobj = new DataLogics();
            return datalogicsobj.DeleteDoctor(docId);
        }
        public InPatient ViewAllDoctorsInfo()
        {
            datalogicsobj = new DataLogics();
            SqlDataReader datalogicsobj.ViewAllDoctors();
        }
    }
}
